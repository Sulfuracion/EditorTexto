package Utilidades;

public class Constantes {
    public static final String URL_BBDD = "jdbc:mysql://localhost/editor_texto";
    public static final String USUARIO_BBDD = "root";
    public static final String CONTRASEÑA_BBDD = "";

    public static String getURL_BBDD() {
        return URL_BBDD;
    }
    public static String getUSUARIO_BBDD() {
        return USUARIO_BBDD;
    }
    public static String getCONTRASEÑA_BBDD() {
            return CONTRASEÑA_BBDD;
    }
}