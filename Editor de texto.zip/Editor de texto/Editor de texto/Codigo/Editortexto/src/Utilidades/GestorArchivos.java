package Utilidades;

import java.awt.Desktop;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class GestorArchivos {


    private String extensionArchivo;
    private String archivoActual;

    public GestorArchivos() {

    }

    public String getArchivoActual() {
        return archivoActual;
    }

    public void setArchivoActual(String archivoActual) {
        this.archivoActual = archivoActual;
    }

    public void crearArchivoNuevo(String nombreArchivo) {
        try {
            File file = new File(nombreArchivo + extensionArchivo);
            if (file.createNewFile()) {
                System.out.println("Se ha creado un nuevo archivo: " + nombreArchivo);
            } else {
                System.out.println("El archivo ya existe.");
            }
        } catch (IOException e) {
            System.out.println("Error al crear el archivo: " + e.getMessage());
        }
    }

    public void abrirArchivo(String nombreArchivo) {
        File file = new File(nombreArchivo + extensionArchivo);

        if (file.exists()) {
            try {
                Desktop.getDesktop().open(file);
                System.out.println("Archivo abierto: " + nombreArchivo);
            } catch (IOException e) {
                System.out.println("Error al abrir el archivo: " + e.getMessage());
            }
        } else {
            System.out.println("El archivo no existe.");
        }
    }

    public void guardarArchivo(String fileName, String content) {
        try {
            File file = new File(fileName);
            FileWriter writer = new FileWriter(file);
            writer.write(content);
            writer.close();
            System.out.println("Archivo guardado: " + fileName);
        } catch (IOException e) {
            System.out.println("Error al guardar el archivo: " + e.getMessage());
        }
    }

    public void editarArchivo(String nombreArchivo) {
        File file = new File(nombreArchivo);

        if (file.exists()) {
            try {
                Scanner scanner = new Scanner(System.in);
                System.out.println("Ingrese el nuevo contenido del archivo:");
                String content = scanner.nextLine();

                FileWriter writer = new FileWriter(file);
                writer.write(content);
                writer.close();

                System.out.println("Archivo editado: " + nombreArchivo);
            } catch (IOException e) {
                System.out.println("Error al editar el archivo: " + e.getMessage());
            }
        } else {
            System.out.println("El archivo no existe.");
        }
    }

    public void borrarArchivo(String nombreArchivo) {
        File file = new File(nombreArchivo + extensionArchivo);

        if (file.exists()) {
            if (file.delete()) {
                System.out.println("Archivo eliminado: " + nombreArchivo);
            } else {
                System.out.println("No se pudo eliminar el archivo.");
            }
        } else {
            System.out.println("El archivo no existe.");
        }
    }

    public void listarArchivos(String directoryPath) {
        File directory = new File(directoryPath);

        if (directory.exists() && directory.isDirectory()) {
            File[] files = directory.listFiles();

            if (files.length > 0) {
                System.out.println("Archivos en el directorio " + directoryPath + ":");
                for (File file : files) {
                    System.out.println(file.getName());
                }
            } else {
                System.out.println("El directorio está vacío.");
            }
        } else {
            System.out.println("El directorio no existe.");
        }
    }

    public String getExtensionArchivo() {
        return extensionArchivo;
    }

    public void setExtensionArchivo(String extensionArchivo) {
        this.extensionArchivo = extensionArchivo;
    }


    public void listarArchivos() {
    }

    public void guardarArchivo(String contenido) {

        try {
            File file = new File(archivoActual + extensionArchivo);
            FileWriter writer = new FileWriter(file);
            writer.write(contenido);
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public String leerArchivo(String nombreArchivo) throws IOException {
        {
            String data = "";
            data = new String(
                    Files.readAllBytes(Paths.get(nombreArchivo)));
            return data;
        }
    }
}
