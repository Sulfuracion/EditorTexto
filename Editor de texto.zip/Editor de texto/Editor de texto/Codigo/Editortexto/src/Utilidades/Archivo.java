package Utilidades;

import java.util.Date;

class Archivo {
    private String nombre;
    private String contenido;
    private Date fechaCreacion;

    public Archivo(String nombre, String contenido, Date fechaCreacion) {
        this.nombre = nombre;
        this.contenido = contenido;
        this.fechaCreacion = fechaCreacion;
    }

    public Archivo(String nombre, String contenido) {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }
}
