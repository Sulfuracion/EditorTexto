package Utilidades;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GestorBaseDatos {
    private Connection conexion;

    public GestorBaseDatos(){

    }

    public void conectarBBDD() {
        try {
            // Configurar los detalles de la conexión a la base de datos
            String url = "jdbc:mysql://localhost:3306/editor_texto";
            String username = "root";
            String password = "";

            // Establecer la conexión
            conexion = DriverManager.getConnection(url, username, password);

            System.out.println("Conectado a la base de datos");
        } catch (SQLException e) {
            System.out.println("Error al conectarse a la base de datos: " + e.getMessage());
        }
    }

    public void desconectarBBDD() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                System.out.println("Desconectado de la base de datos con éxito.");
            }
        } catch (SQLException e) {
            System.out.println("Error al desconectarse de la base de datos: " + e.getMessage());
        }
    }

    public void crearArchivo(Archivo archivo) {
        try {
            // Preparar la consulta SQL
            String sql = "INSERT INTO archivos (nombre, contenido) VALUES (?, ?)";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setString(1, archivo.getNombre());
            statement.setString(2, archivo.getContenido());

            // Ejecutar la consulta
            int rowsInserted = statement.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("Archivo '" + archivo.getNombre() + "' creado correctamente en la base de datos. ");
            } else {
                System.out.println("No se pudo crear el archivo en la base de datos");
            }

            // Cerrar el PreparedStatement
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error al crear el archivo en la base de datos: " + e.getMessage());
        }
    }

    public void actualizarArchivo(Archivo archivo) {
        try {
            // Preparar la consulta SQL
            String sql = "UPDATE archivos SET contenido = ? WHERE nombre = ?";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setString(1, archivo.getContenido());
            statement.setString(2, archivo.getNombre());

            // Ejecutar la consulta
            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Archivo " + archivo.getNombre() + " actualizado correctamente en la base de datos.");
            } else {
                System.out.println("No se pudo actualizar el archivo en la base de datos");
            }

            // Cerrar el PreparedStatement
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error al actualizar el archivo en la base de datos: " + e.getMessage());
        }
    }

    public void borrarArchivo(String nombreArchivo) {
        try {
            // Preparar la consulta SQL
            String sql = "DELETE FROM archivos WHERE nombre = ?";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setString(1, nombreArchivo);

            // Ejecutar la consulta
            int rowsDeleted = statement.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("Archivo " + nombreArchivo + " eliminado correctamente de la base de datos.");
            } else {
                System.out.println("No se pudo eliminar el archivo de la base de datos");
            }

            // Cerrar el PreparedStatement
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error al eliminar el archivo de la base de datos: " + e.getMessage());
        }
    }

    public Archivo recuperarArchivo(String nombreArchivo) {
        try {
            // Preparar la consulta SQL
            String sql = "SELECT contenido FROM archivos WHERE nombre = ?";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setString(1, nombreArchivo);

            // Ejecutar la consulta
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String contenido = resultSet.getString("contenido");
                System.out.println("Obteniendo archivo " + nombreArchivo + " de la base de datos...");
                return new Archivo(nombreArchivo, contenido);
            } else {
                System.out.println("No se encontró el archivo en la base de datos");
            }

            // Cerrar el ResultSet y el PreparedStatement
            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error al obtener el archivo de la base de datos: " + e.getMessage());
        }

        return null;
    }

    public List<Archivo> obtenerTodosLosArchivos() {
        List<Archivo> archivos = new ArrayList<>();

        try {
            // Preparar la consulta SQL
            String sql = "SELECT nombre, contenido FROM archivos";
            PreparedStatement statement = conexion.prepareStatement(sql);

            // Ejecutar la consulta
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String nombre = resultSet.getString("nombre");
                String contenido = resultSet.getString("contenido");
                archivos.add(new Archivo(nombre, contenido));
            }

            System.out.println("Obteniendo todos los archivos de la base de datos");

            // Cerrar el ResultSet y el PreparedStatement
            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error al obtener los archivos de la base de datos: " + e.getMessage());
        }

        return archivos;
    }
}
